#!/bin/bash
#Function: pipeline for unitary gene loss detection
#Usage:    program name_of_genome_for_gene_loss_detection

read -a genomes -p "Please input names of genomes for gene loss detection, you can detect gene loss for one species or the MRCA (most recent common ancestor) of multiple species:
"

for num in `seq 1 ${#genomes[*]}`; do echo ${genomes[$num-1]} >> genomes_list.tsv; done
genomes_list=`paste -d "_" -s genomes_list.tsv`
mkdir $genomes_list
mv BLAST_database GMAP_database ppipe_output $genomes_list

if [ -f orthologous_groups.tsv ]
then 
echo -ne "orthologous_groups.tsv has existed.\n"
else
extract_orthologous_group.sh
fi

if [ -f modified_EVS009_Supplemental_dataset_S1_pluslinks.tsv ]
then
echo -ne "modified_EVS009_Supplemental_dataset_S1_pluslinks.tsv has existed.\n"
else
awk -F "\t" '{print $1 "\t" $2 "\t" $3 "\t" $4 "\t" $5 "\t" $11 "\n" $6 "\t" $7 "\t" $8 "\t" $9 "\t" $10 "\t" $11}' EVS009_Supplemental_dataset_S1_pluslinks.tsv > modified_EVS009_Supplemental_dataset_S1_pluslinks.tsv
fi

rm -rf genomes_list.tsv

cd $genomes_list

echo ${genomes[*]} | detect_candidate_unitary_gene_loss_based_on_orthologous_group.sh

mkdir classify_candidate_gene_loss

for num in `seq 1 ${#genomes[*]}`; do mkdir classify_candidate_gene_loss/${genomes[$num-1]}; done

for num in `seq 1 ${#genomes[*]}`; do cd classify_candidate_gene_loss/${genomes[$num-1]}; classify_candidate_unitary_gene_loss.sh ${genomes[$num-1]}; cd ../..; done

mkdir ensure_relic-retaining_gene_loss

for num in `seq 1 ${#genomes[*]}`; do mkdir ensure_relic-retaining_gene_loss/${genomes[$num-1]}; done

for num in `seq 1 ${#genomes[*]}`; do cd ensure_relic-retaining_gene_loss/${genomes[$num-1]}; ensure_relic-retaining_unitary_gene_loss.sh ${genomes[$num-1]}; cd ../..; done

mkdir locate_relic-lacking_gene_loss

for num in `seq 1 ${#genomes[*]}`; do mkdir locate_relic-lacking_gene_loss/${genomes[$num-1]}; done

for num in `seq 1 ${#genomes[*]}`; do cd locate_relic-lacking_gene_loss/${genomes[$num-1]}; locate_relic-lacking_unitary_gene_loss.sh ${genomes[$num-1]}; cd ../..; done

echo ${genomes[*]} | integrate_unitary_gene_loss_info.sh

cd ..


