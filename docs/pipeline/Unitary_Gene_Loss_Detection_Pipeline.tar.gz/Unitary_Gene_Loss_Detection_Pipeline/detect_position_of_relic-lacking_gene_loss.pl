#!/usr/bin/perl
#Function: detect position of relic-lacking gene loss based on synteny data from CoGe
#Usage:    program genome_with_relic-lacking_gene_loss

use strict;
use warnings;

my $lost_genome = shift;

my @osm_pattern = ("LOC","[0-9]+\.t[0-9]+");
my @bdi_pattern = ("BRADI");
my @sbi_pattern = ("Sb");
my @zm_pattern  = ("GRMZM","EF","AF","AY","AC");

my %pattern;
$pattern{osm} = \@osm_pattern;
$pattern{bdi} = \@bdi_pattern;
$pattern{sbi} = \@sbi_pattern;
$pattern{zm}  = \@zm_pattern;

open LOSS_MEMBER,    "../../orthologous_groups_with_candidate_unitary_gene_loss_in_${lost_genome}.tsv";
open SELECTED_GROUP, "../../classify_candidate_gene_loss/$lost_genome/relic-lacking.group";
open SELECTED_MEMBER,">relic-lacking.member";

my %group_member_hash;

while (<LOSS_MEMBER>){
  chomp;
  my @c = split/\t/,$_;
  my $orthologous_group_num = $1 if $c[0] =~ /orthologous_group_([0-9]+)_containing/;
  $group_member_hash{$orthologous_group_num} = $_;
}

while (<SELECTED_GROUP>){
  chomp;
  print SELECTED_MEMBER "$group_member_hash{$_}\n";
}

close LOSS_MEMBER;
close SELECTED_GROUP;
close SELECTED_MEMBER;

open INPUT,  "relic-lacking.member";
open COGE,   "../../../modified_EVS009_Supplemental_dataset_S1_pluslinks.tsv";
open OUTPUT, ">position_of_${lost_genome}_loss_relic-lacking.tsv";

chomp (my @input = <INPUT>);
chomp (my @coge = <COGE>);

print OUTPUT "orthologous_group_with_gene_loss\tparental_pep\tloss_chr\tloss_strand\tloss_start\tloss_end\tposition_status\torganism_with_gene_loss\n";

foreach my $input (@input){
  my %parental_genome_flag = ();
  my @all_parental_genomes;
  my @c = split /\t/, $input;

  $parental_genome_flag{bdi} = 0;
  $parental_genome_flag{osm} = 0;
  $parental_genome_flag{sbi} = 0;
  $parental_genome_flag{zm}  = 0;

  foreach my $c (@c){
    foreach my $pattern (@{$pattern{bdi}}){
      if ($c =~ /$pattern/){
        $parental_genome_flag{bdi} += 1;
      }
    }

    foreach my $pattern (@{$pattern{osm}}){
      if ($c =~ /$pattern/){
        $parental_genome_flag{osm} += 1;
      }
    }

    foreach my $pattern (@{$pattern{sbi}}){
      if ($c =~ /$pattern/){
        $parental_genome_flag{sbi} += 1;
      }
    }
  
    foreach my $pattern (@{$pattern{zm}}){
      if ($c =~ /$pattern/){
        $parental_genome_flag{zm} += 1;
      }
    }
  }  
    
  push @all_parental_genomes, "bdi" if $parental_genome_flag{bdi} > 0;
  push @all_parental_genomes, "osm" if $parental_genome_flag{osm} > 0;
  push @all_parental_genomes, "sbi" if $parental_genome_flag{sbi} > 0;
  push @all_parental_genomes, "zm" if $parental_genome_flag{zm} > 0;
  
  foreach my $one_parental_genome (@all_parental_genomes){
    &position_function($input, \@coge, $lost_genome, $one_parental_genome);
  }
}

sub position_function{

  my ($input, $coge, $lost_genome, $parental_genome) = @_;

  my @parental_pep_list  = ();
  my %member;	
  my $flag_synteny       = 0;
  my $flag_loss_position = 0;

  my @c = split /\t/, $input;
		
  my $orthologous_group = $1 if $c[0] =~ /orthologous_group_([0-9]+)/;

  foreach my $c (@c){
    foreach my $pattern (@{$pattern{$parental_genome}}){  
      if ($c =~ /$pattern/){
	push @parental_pep_list, $c;
      }
    }
  }

  foreach my $parental_pep (@parental_pep_list){
    foreach my $coge (@{$coge}){
      next if $coge =~ /GEvo/;
      my @cc = split /\t/, $coge; 
      my @bdi_member = ($cc[4]); 
      my @osm_member = ($cc[3]); 
      my @sbi_member = ($cc[2]); 
      my @zm_member  = ($cc[0],$cc[1]); 
      $member{bdi} = \@bdi_member;
      $member{osm} = \@osm_member;
      $member{sbi} = \@sbi_member;
      $member{zm}  = \@zm_member;

      foreach my $parental_member (@{$member{$parental_genome}}){
        my @parental_member_content = split /\|\|/, $parental_member;
        foreach my $parental_member_content (@parental_member_content){			
	  if ($parental_member_content eq $parental_pep){
            $flag_synteny = 1; 
            $flag_loss_position = 0;
	    foreach my $lost_member (@{$member{$lost_genome}}){
              if ($lost_member =~ /chr([0-9]+):([0-9]+)-([0-9]+):([0-9]+):([\S]+)/){
		$flag_loss_position = 1; 
                print OUTPUT "$orthologous_group\t$parental_pep\t$1\t-\t$2\t$3\t$5\t$lost_genome\n" if $4 == 0;
		print OUTPUT "$orthologous_group\t$parental_pep\t$1\t+\t$2\t$3\t$5\t$lost_genome\n" if $4 == 1;
              }
            }
            print OUTPUT "$orthologous_group\t$parental_pep\tNA\tNA\tNA\tNA\tunknown\t$lost_genome\n" if $flag_loss_position == 0;
          }
        }
      }
    }
    print OUTPUT "$orthologous_group\t$parental_pep\tNA\tNA\tNA\tNA\tNA\tnot_in_synteny\t$lost_genome\n" if $flag_synteny == 0;
  }
}

close INPUT;
close OUTPUT;
close COGE;
