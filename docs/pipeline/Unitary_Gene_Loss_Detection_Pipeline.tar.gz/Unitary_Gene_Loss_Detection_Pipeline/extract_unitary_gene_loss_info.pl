#!/usr/bin/perl
#Function: extract detailed information for unitary gene loss events
#Usage:    program genome_names_with_unitary_gene_loss

use strict;
use warnings;

my @genomes_with_gene_loss =@ARGV;

my %genome_relic_retaining_hash;
my %genome_relic_lacking_hash;

foreach my $genome (@genomes_with_gene_loss){
  open RELIC_RETAINING, "ensure_relic-retaining_gene_loss/$genome/relic-retaining_unitary_gene_loss_of_$genome.info";
  open RELIC_LACKING,   "locate_relic-lacking_gene_loss/$genome/relic-lacking_unitary_gene_loss_of_$genome.info";
  
  chomp (my @relic_retaining = <RELIC_RETAINING>);
  chomp (my @relic_lacking = <RELIC_LACKING>);
  
  $genome_relic_retaining_hash{$genome} = \@relic_retaining;
  $genome_relic_lacking_hash{$genome} = \@relic_lacking;
  
  close RELIC_RETAINING;
  close RELIC_LACKING;
}

my $genomes_with_gene_loss = join "_", @genomes_with_gene_loss;

open IN, "unitary_gene_loss_summary_for_${genomes_with_gene_loss}.tsv";
open OUT, ">unitary_gene_loss_info_for_${genomes_with_gene_loss}.tsv";

while (<IN>){
  chomp;
  my @c = split/\t/,$_;
  my $num = @c;
  for (my $i=1; $i<$num-1; $i++){
    if ($c[$i] eq "relic-retaining"){
      foreach my $relic_retaining (@{$genome_relic_retaining_hash{$genomes_with_gene_loss[$i-1]}}){
        my @relic_retaining_detail = split/\t/, $relic_retaining;
	print OUT "$relic_retaining\trelic-retaining\t$genomes_with_gene_loss[$i-1]\n" if $relic_retaining_detail[0] eq $c[0];
      }
    }
    if ($c[$i] eq "relic-lacking"){
      foreach my $relic_lacking (@{$genome_relic_lacking_hash{$genomes_with_gene_loss[$i-1]}}){
        my @relic_lacking_detail = split/\t/, $relic_lacking;
	print OUT "$relic_lacking\trelic-lacking\t$genomes_with_gene_loss[$i-1]\n" if $relic_lacking_detail[0] eq $c[0];
      }
    }
  }
}
