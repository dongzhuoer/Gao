#!/bin/bash
#Function: ensure relic-retaining unitary gene loss based on disabler detection via GeneWise
#Usage:    program genome_with_gene_loss

genome=$1

#run GeneWise for selected relic
cat ../../ppipe_output/${genome}/pgenes/${genome}_pgenes_with_the_lowest_evalue_info.tsv | while read line; do echo -ne "#\t$(echo "$line" | cut -f4)\n" >> genewise_result_for_${genome}_relic.tsv; get-genome -D ../../GMAP_database/$genome -d $genome $(echo "$line" | cut -f1) > relic; fastacmd -d ../../BLAST_database/Poaceae_viv_ath_pop_longest -p T -s $(echo "$line" | cut -f3) > pep; genewise pep relic -subs 1e-02 -indel 1e-02 -splice flat -sum -pep >> genewise_result_for_${genome}_relic.tsv; don

rm -rf pep relic

#select relic containing disablers detected by GeneWise
display_disabler_info_for_relics.pl $genome

awk -F "\t" '$7>0 || $8>0 {print $1}' disabler_info_for_${genome}_relic.tsv > relic-retaining_unitary_gene_loss_of_${genome}.group
sed -e '/orthologous_group_with_unitary_gene_loss/d' -i relic-retaining_unitary_gene_loss_of_${genome}.group

awk -F "\t" '$7>0 || $8>0 {print}' disabler_info_for_${genome}_relic.tsv > relic-retaining_unitary_gene_loss_of_${genome}.info
sed -e '/orthologous_group_with_unitary_gene_loss/d' -i relic-retaining_unitary_gene_loss_of_${genome}.info
