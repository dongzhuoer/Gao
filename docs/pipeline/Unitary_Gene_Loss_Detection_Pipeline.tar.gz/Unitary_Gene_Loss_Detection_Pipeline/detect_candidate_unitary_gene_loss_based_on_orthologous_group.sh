#!/bin/bash
#Function: detect candidate unitary gene loss happened in different species
#Usage:    program name_of_genome_for_gene_loss_detection

read -a genomes -p "Please input names of genomes for gene loss detection, you can detect gene loss for one species or the MRCA (most recent common ancestor) of multiple species:
"

extract_orthologous_group_with_candidate_unitary_gene_loss.pl ${genomes[*]}

if [ ${#genomes[*]} -gt 1 ]

then

for num in `seq 1 ${#genomes[*]}`; do echo ${genomes[$num-1]} >> genomes_list.tsv; done

genomes_list=`paste -d "_" -s genomes_list.tsv`

for num in `seq 1 ${#genomes[*]}`; do cp orthologous_groups_with_candidate_unitary_gene_loss_in_${genomes_list}.tsv orthologous_groups_with_candidate_unitary_gene_loss_in_${genomes[$num-1]}.tsv; done

fi

rm -rf genomes_list.tsv
