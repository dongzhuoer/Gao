#!/usr/bin/perl
#Function: calculate ortholog amount for each species in orthologous group
#Usage:    cat raw_orthologous_group.tsv | program > orthologous_group.tsv

use strict;
use warnings;

my $num;

while (<>){

  chomp;
  
  my $osm = 0;
  my $bdi = 0;
  my $sbi = 0;
  my $zm  = 0;
  my $viv = 0;
  my $pop = 0;
  my $ath = 0;

  $num += 1;

  my @c = split /\t/, $_;
  
  foreach my $c (@c){
    $osm += 1 if $c =~ /\.t/ || $c=~/LOC/;
    $bdi += 1 if $c =~ /BRADI/;
    $sbi += 1 if $c =~ /Sb/;
    $zm  += 1 if $c =~ /AC/ || $c=~/AF/ || $c=~/AY/ || $c=~/EF/ || $c=~/GRMZM/;
    $viv += 1 if $c =~ /Vv/;
    $ath += 1 if $c =~ /AT/;
    $pop += 1 if $c =~ /POPTR/;
  }
  
  my $total = $osm + $bdi + $sbi + $zm + $viv + $ath + $pop;
  
  print "orthologous_group_${num}_containing_osm_${osm}_bdi_${bdi}_sbi_${sbi}_zm_${zm}_viv_${viv}_ath_${ath}_pop_${pop}_total_${total}";
  foreach my $c (@c){
    next if $c =~ /^[0-9]+$/;
    print "\t$c";
  }
  print "\n";

}
