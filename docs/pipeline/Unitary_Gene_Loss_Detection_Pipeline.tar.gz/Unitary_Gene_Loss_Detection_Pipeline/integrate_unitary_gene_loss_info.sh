#!/bin/bash
#Function: integrate information for unitary gene loss events
#Usage:    program genome_names_with_unitary_gene_loss

read -a genomes -p "Please input names of genomes for gene loss detection, you can detect gene loss for one or multiple species:
"

summarize_unitary_gene_loss_info.pl ${genomes[*]}

extract_unitary_gene_loss_info.pl ${genomes[*]}

