#!/usr/bin/perl
#Function: select pgenes with the lowest evalue
#Usage:    program genome_with_gene_loss

use strict;
use warnings;

my $genome = shift;

open INPUT,     "../../ppipe_output/$genome/pgenes/${genome}_pgenes.tsv";
open OUTPUT,    ">../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv";

my %group_info_hash;
my %group_evalue_hash;

while (<INPUT>){

  chomp;
  my @c = split /\t/, $_;
  my $orthologous_group = $c[14];
  next if $orthologous_group eq "NA";
  my $pgene_evalue = $c[10];
  my $pgene_info = $_;

  if (!exists $group_evalue_hash{$orthologous_group} && !exists $group_info_hash{$orthologous_group}){
    $group_evalue_hash{$orthologous_group} = $pgene_evalue;
    $group_info_hash{$orthologous_group} = $pgene_info;
  }

  else {
    if ($pgene_evalue < $group_evalue_hash{$orthologous_group}){
      $group_evalue_hash{$orthologous_group} = $pgene_evalue;
      $group_info_hash{$orthologous_group} = $pgene_info;
    }
  }

}

foreach my $k (keys %group_info_hash){
  print OUTPUT "$group_info_hash{$k}\n";
}

close INPUT;
close OUTPUT;

open INPUT,  "../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv";
open OUTPUT, ">../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue_info.tsv";

while (<INPUT>){

  chomp;
  my @c = split /\t/, $_;
  my $chr    = $c[0];
  my $start  = $c[1];
  my $end    = $c[2];
  my $strand = $c[3];
  my $pep    = $c[4];
  my $group  = $c[14];
  next if $group eq "NA";
  
  my $coordinate = $chr . ":" . $start . ".." . $end if $strand eq "+";
  $coordinate = $chr . ":" . $end . ".." . $start if $strand eq "-";
  
  print OUTPUT "$coordinate\t$strand\t$pep\t$group\n";

}

close INPUT;
close OUTPUT;








