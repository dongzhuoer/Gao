#!/bin/bash
#Function: extract orthologous relationship from EnsemblPlants via MySQL and construct orthologous group
#Usage:    program

#extract orthologous relationship from EnsemblPlants via MySQL
mysql -h mysql.ebi.ac.uk -P 4157 -u anonymous -e "use ensembl_compara_plants_15_68; select homology.homology_id, homology.description, homology.subtype, ncbi_taxa_name.name, member.stable_id from homology, homology_member, member, ncbi_taxa_name where member.taxon_id = ncbi_taxa_name.taxon_id and homology_member.member_id = member.member_id and homology.homology_id = homology_member.homology_id and homology.description like 'ortholog%' and (ncbi_taxa_name.name = 'Oryza sativa japonica' or ncbi_taxa_name.name = 'Brachypodium distachyon' or ncbi_taxa_name.name = 'Sorghum bicolor' or ncbi_taxa_name.name = 'Zea mays' or ncbi_taxa_name.name = 'Vitis vinifera' or ncbi_taxa_name.name = 'Arabidopsis thaliana' or ncbi_taxa_name.name = 'Populus trichocarpa') ;" > orthologous_relationships.tsv

#extract information from orthologous relationship
cut -f1,5 orthologous_relationships.tsv | grep -v homology_id > orthologous_relationships_info.tsv

#construct orthologous group
cat orthologous_relationships_info.tsv | extract_connected_components_of_graph.c > raw_orthologous_groups.tsv

#calculate ortholog amount for each species in orthologous group
cat raw_orthologous_groups.tsv | calculate_orthologs_amount_of_each_species.pl > orthologous_groups.tsv























