#!/usr/bin/perl
#Function: summarize infomation of unitary gene loss events
#Usage:    program genome_names_with_unitary_gene_loss

use strict;
use warnings;

my @genomes_with_gene_loss = @ARGV;

my @all_genomes = @genomes_with_gene_loss;
my $all_genomes_num = @genomes_with_gene_loss;
my (%genome_relic_retaining_hash, %genome_relic_lacking_hash);
my @gene_loss_info;

foreach my $genome (@genomes_with_gene_loss){
  
  open RELIC_RETAINING, "ensure_relic-retaining_gene_loss/$genome/relic-retaining_unitary_gene_loss_of_$genome.group";
  open RELIC_LACKING,   "locate_relic-lacking_gene_loss/$genome/relic-lacking_unitary_gene_loss_of_$genome.group";
  
  chomp (my @relic_retaining = <RELIC_RETAINING>);
  chomp (my @relic_lacking = <RELIC_LACKING>);
  
  $genome_relic_retaining_hash{$genome} = \@relic_retaining;
  $genome_relic_lacking_hash{$genome} = \@relic_lacking;
  
  foreach my $relic_retaining (@{$genome_relic_retaining_hash{$genome}}){
    push @gene_loss_info, "$relic_retaining\trelic-retaining\t$genome\n";
  }
  foreach my $relic_lacking (@{$genome_relic_lacking_hash{$genome}}){
    push @gene_loss_info, "$relic_lacking\trelic-lacking\t$genome\n";
  }
  
  close RELIC_RETAINING;
  close RELIC_LACKING;
}

my %group_hash;

foreach my $gene_loss_info (@gene_loss_info){
  chomp ($gene_loss_info);
  my @c = split/\t/,$gene_loss_info; 
  $group_hash{$c[0]} = 1;
}

my $genomes_with_gene_loss = join "_", @genomes_with_gene_loss;

open OUT, ">unitary_gene_loss_summary_for_${genomes_with_gene_loss}.tsv";

print OUT "orthologous_group_with_unitary_gene_loss";
foreach my $genome (@genomes_with_gene_loss){
  print OUT "\t$genome";
}
print OUT "\tunitary_gene_loss_status\n";

foreach my $k (keys %group_hash){
  my @gene_loss_summary;
  my @all_genomes;
  push @gene_loss_summary, "$k";
  foreach my $genome (@genomes_with_gene_loss){
    my $flag = 0;
    foreach my $gene_loss_info (@gene_loss_info){
      my @c = split/\t/,$gene_loss_info;
      if ($c[0] eq $k){
        if ($c[2] eq $genome){
          push @gene_loss_summary, "$c[1]";
          push @all_genomes, $genome;
	  $flag = 1;
	}
      }
    }  
    if ($flag == 0){
      push @gene_loss_summary, "NA";
    }
  }    
  my $all_genomes = join "_", @all_genomes;
  push @gene_loss_summary, $all_genomes;
  my $gene_loss_summary = join "\t", @gene_loss_summary;
  print OUT "$gene_loss_summary\n";
}
