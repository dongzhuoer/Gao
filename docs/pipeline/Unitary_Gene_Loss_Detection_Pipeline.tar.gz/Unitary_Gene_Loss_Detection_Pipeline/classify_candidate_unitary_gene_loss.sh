#!/bin/bash
#Function: classify gene loss as False Positive, relic-retaining or relic-lacking unitary gene loss based on PseudoPipe output
#Usage: program genome_with_gene_loss

genome=$1

#DATA PREPARING
cat ../../ppipe_output/$genome/pgenes/${genome}_pgenes.txt | grep -v "#" > ../../ppipe_output/$genome/pgenes/modified_${genome}_pgenes.txt

cut -f5 ../../ppipe_output/$genome/pgenes/modified_${genome}_pgenes.txt > pgenes.query

project_pep_on_orthologous_group.pl pgenes.query ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv pgenes.group

paste ../../ppipe_output/$genome/pgenes/modified_${genome}_pgenes.txt pgenes.group | sort -nk15 -o ../../ppipe_output/$genome/pgenes/${genome}_pgenes.tsv

select_pgene_with_the_lowest_evalue.pl $genome

cat ../../ppipe_output/$genome/blast/processed/*.sorted | cut -f1 | grep -v '#' | sort | uniq > all_blastHits.query

cat ../../ppipe_output/$genome/pgenes/{plus,minus}/gff/ensembl-gene-masked/* | cut -f1 | grep -v '#' | sort | uniq > masked_blastHits.query

project_pep_on_orthologous_group.pl all_blastHits.query ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv all_blastHits.group

project_pep_on_orthologous_group.pl masked_blastHits.query ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv masked_blastHits.group

#FALSE POSITIVE GENE LOSS
sort all_blastHits.group | uniq | sort -o all_blastHits.group

sort masked_blastHits.group | uniq | sort -o masked_blastHits.group

comm -23 all_blastHits.group masked_blastHits.group >> FP.group

grep "GENE" ../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv | cut -f5 > entire_gene_structure.query

project_pep_on_orthologous_group.pl entire_gene_structure.query ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv entire_gene_structure.group

cat entire_gene_structure.group >> FP.group

sort FP.group | uniq | sort -o FP.group

#RELIC-RETAINING GENE LOSS
grep "PSSD" ../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv | cut -f5 >> relic-retaining.query

grep "DUP" ../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv | cut -f5 >> relic-retaining.query

project_pep_on_orthologous_group.pl relic-retaining.query ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv relic-retaining.group

sort relic-retaining.group | uniq | sort -o relic-retaining.group

comm -13 FP.group relic-retaining.group | sort -o relic-retaining.group

cat FP.group relic-retaining.group | sort -o FP_and_relic-retaining.group

#RELIC-LACKING GENE LOSS
grep "FP" ../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv | cut -f5 >> relic-lacking.query

grep "FRAG" ../../ppipe_output/$genome/pgenes/${genome}_pgenes_with_the_lowest_evalue.tsv | cut -f5 >> relic-lacking.query

project_pep_on_orthologous_group.pl relic-lacking.query ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv relic-lacking.group

awk -F "_" '{print $3}' ../../orthologous_groups_with_candidate_unitary_gene_loss_in_${genome}.tsv | sort | uniq | sort -o candidate_unitary_gene_loss.group

comm -23 candidate_unitary_gene_loss.group all_blastHits.group >> relic-lacking.group

sort relic-lacking.group | uniq | sort -o relic-lacking.group

cat FP.group relic-retaining.group relic-lacking.group | sort | uniq | sort -o detected_by_now.group

comm -23 candidate_unitary_gene_loss.group detected_by_now.group >> relic-lacking.group

sort relic-lacking.group | uniq | sort -o relic-lacking.group

comm -13 FP_and_relic-retaining.group relic-lacking.group | sort -o relic-lacking.group
