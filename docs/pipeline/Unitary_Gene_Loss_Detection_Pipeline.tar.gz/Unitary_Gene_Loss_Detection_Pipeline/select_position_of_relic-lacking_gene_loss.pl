#!/usr/bin/perl
#Function: select and summarize position of each relic-lacking unitary gene loss
#Usage:    program organism_with_gene_loss

use strict;
use warnings;

my $genome = shift;

open GROUP,    "relic-lacking.member";
open POSITION, "position_of_${genome}_loss_relic-lacking.tsv";
open COGE,     "../../../modified_EVS009_Supplemental_dataset_S1_pluslinks.tsv";

chomp (my @position = <POSITION>);
chomp (my @coge = <COGE>);

open STATUS,    ">position_of_${genome}_loss_relic-lacking.status"; 
open GROUP_OUT, ">relic-lacking_unitary_gene_loss_of_$genome.group";
open INFO_OUT,  ">relic-lacking_unitary_gene_loss_of_$genome.info";

while(<GROUP>){

  chomp;
  my @c = split /\t/, $_;
  my $orthologous_group = $1 if $c[0] =~ /orthologous_group_([0-9]+)_containing/;
  
  my $flag = 0;
  my $max = 0;
  my %pep_hit_hash = ();
  my $final_parental_pep;
  
  foreach my $position (@position){
    my @cc = split /\t/, $position;
    if ($orthologous_group eq $cc[0]){
      my $parental_pep = $cc[1];
      foreach my $coge (@coge){
        my @coge_content = split/\t/, $coge;
	foreach my $coge_content (@coge_content){
	  my @coge_detail = split /\|\|/, $coge_content;
	  foreach my $coge_detail (@coge_detail){
	    if ($coge_detail eq $parental_pep){
	      $flag = 1;
	      my @selected_coge_content = @coge_content;
              foreach my $c (@c){
	        foreach my $selected_coge_content (@selected_coge_content){
	          my @selected_coge_detail = split /\|\|/, $selected_coge_content;
	          foreach my $selected_coge_detail (@selected_coge_detail){
	            $pep_hit_hash{$parental_pep} += 1 if $c eq $selected_coge_detail
	          }
	        }
	      }
            }
          }
        }
      }
    }
  }
  
  if ($flag == 0){
    print STATUS "$orthologous_group\tnot_in_synteny\t$genome\n";
    next;
  }
  
  foreach my $key (keys %pep_hit_hash){
    if ($pep_hit_hash{$key} > $max){
      $max = $pep_hit_hash{$key};
      $final_parental_pep = $key;
    }
  }
  
  foreach my $position (@position){
    my @c = split/\t/, $position;
    if ($c[1] eq $final_parental_pep){
      print STATUS "$c[0]\t$c[6]\t$c[7]\n";
      if ($c[2] ne "NA" && $c[6] ne "gap" && $c[6] ne "unknown" && $c[6] ne "not_in_synteny"){
        print GROUP_OUT "$c[0]\n";
	print INFO_OUT "$c[0]\t$c[1]\t$c[2]\t$c[4]\t$c[5]\t$c[3]\tNA\tNA\n";
      }
    }
  }
}

