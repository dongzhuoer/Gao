#!/usr/bin/perl
#Function: extract orthologous group with candidate unitary gene loss based on ortholog amount of each species
#Usage:    program genome_names_with_unitary_gene_loss

use strict;
use warnings;

my @species_with_gene_loss = @ARGV;

open INPUT,          "../orthologous_groups.tsv";
open FORBIDDEN_GENE, "../forbidden_gene_list.tsv";
my $species_list = join "_", @species_with_gene_loss;
open OUTPUT, ">orthologous_groups_with_candidate_unitary_gene_loss_in_$species_list.tsv";

chomp (my @forbidden_gene = <FORBIDDEN_GENE>);

my %species_hash;
foreach my $species (@species_with_gene_loss){
  $species_hash{$species} = 1;
}

while (<INPUT>){

  chomp;
  
  my @c = split/\t/, $_; 
  my %orthologs_amount;
  my $flag = 1;
  
  if ( $c[0] =~ /orthologous_group_[0-9]+_containing_osm_([0-9]+)_bdi_([0-9]+)_sbi_([0-9]+)_zm_([0-9]+)_viv_([0-9]+)_ath_([0-9]+)_pop_([0-9]+)_total_[0-9]+/){
    $orthologs_amount{osm} = $1;
    $orthologs_amount{bdi} = $2;
    $orthologs_amount{sbi} = $3;
    $orthologs_amount{zm}  = $4;
    $orthologs_amount{viv} = $5;
    $orthologs_amount{ath} = $6;
    $orthologs_amount{pop} = $7;
  }

  foreach my $key (keys %orthologs_amount){
    $flag = 0 if exists($species_hash{$key})&& $orthologs_amount{$key}  > 0;
    $flag = 0 if !exists($species_hash{$key}) && $orthologs_amount{$key} == 0;
  }
  
  foreach my $forbidden_gene (@forbidden_gene){
    $flag = 0 if $flag == 1 && /$forbidden_gene/;
  }

  print OUTPUT "$_\n" if $flag == 1;
  
}
