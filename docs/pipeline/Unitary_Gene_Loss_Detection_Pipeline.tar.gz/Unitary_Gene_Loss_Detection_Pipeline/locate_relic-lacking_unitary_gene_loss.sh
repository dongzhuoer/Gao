#!/bin/bash
#Function: locate relic-lacking unitary gene loss based on synteny data from CoGe
#Usage:    program genome_with_relic-lacking_gene_loss

genome=$1

detect_position_of_relic-lacking_gene_loss.pl $genome

sort -nk1 position_of_${genome}_loss_relic-lacking.tsv | uniq | sort -nk1 -o position_of_${genome}_loss_relic-lacking.tsv

select_position_of_relic-lacking_gene_loss.pl $genome

