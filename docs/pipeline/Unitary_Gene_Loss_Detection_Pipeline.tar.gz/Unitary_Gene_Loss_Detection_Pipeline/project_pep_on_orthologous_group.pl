#!/usr/bin/perl
#Function: project pep on orthologous group 
#Usage:    program pep_list_file orthologous_group_file output_file_with_pep_name_and_orthologous_group_number

use strict;
use warnings;

my $pep_list          = shift;
my $orthologous_group = shift;
my $output            = shift;

open PEP,    "$pep_list";
open GROUP,  "$orthologous_group";
open OUTPUT, ">$output";

chomp(my @pep   = <PEP>);
chomp(my @group = <GROUP>);

my %pep_group_hash;

foreach my $group (@group){

  my @c = split /\t/, $group;
  my $orthologous_group_num = $1 if $c[0] =~ /orthologous_group_([0-9]+)/;
  foreach my $c (@c){
    $pep_group_hash{$c} = $orthologous_group_num;
  }

}

foreach my $pep (@pep){
  print OUTPUT "$pep_group_hash{$pep}\n" if exists $pep_group_hash{$pep};
  print OUTPUT "NA\n" if !exists $pep_group_hash{$pep};
}
