#!/usr/bin/perl
#Function: selecte relics containing disablers detected by GeneWise
#Usage:    program genome_with_relic

use strict;
use warnings;

my $genome = shift;

open INPUT,  "genewise_result_for_${genome}_relic.tsv";
open RELIC,  "../../classify_candidate_gene_loss/$genome/relic-retaining.group";
open OUTPUT, ">disabler_info_for_${genome}_relic.tsv";

chomp (my @relic = <RELIC>);
my %relic_hash;

foreach my $relic (@relic){
  $relic_hash{$relic} = 1;
}

print OUTPUT "orthologous_group_with_unitary_gene_loss\tfunctional_counterpart\tchr\tstart\tend\tstrand\tframeshift_num\tpreliminary_stop-codon_num\n";

my ($orthologous_group_num, $parental_pep, $chr, $start, $end, $strand);

my $flag      = 0;
my $total_num = 0;
my $stop_num  = 0;
my $frame_num = 0;


while (<INPUT>){

  chomp; 
  if (/#/){
    my @orthologous_group_info = split /\t/, $_;
    $orthologous_group_num  = $orthologous_group_info[1];
    next;
  }
  
  next if /Making/; 
  
  my @c = split;
  my $num = @c;
  
  if (/Bits/ && $flag == 1){
    next if !exists $relic_hash{$orthologous_group_num};
    $stop_num = $total_num - $frame_num;
    print OUTPUT "$stop_num\n";
    $total_num = 0;
  }
  
  if ($num == 9 && $_ !~ /Bits/){
    next if !exists $relic_hash{$orthologous_group_num};
    $parental_pep = $1 if $c[1] =~ /lcl\|([\S]+)/;
    my $relic_pos = $c[4];
    if ($relic_pos =~ /([0-9]+):([0-9]+)\.\.([0-9]+)/){
      $chr = $1;
      if ($2 < $3){
        $strand = "+";
        $start = $2;
	$end = $3;
      }
      if ($2 > $3){
        $strand = "-";
	$start = $3;
	$end = $2;
      }
    }
    $frame_num = $c[7];
    print OUTPUT "$orthologous_group_num\t$parental_pep\t$chr\t$start\t$end\t$strand\t$frame_num\t"
  }
  
  if ($num ne 9){
    next if !exists $relic_hash{$orthologous_group_num};
    my @cc = split //, $_;
    foreach my $cc (@cc){
      $total_num += 1 if $cc eq "X";
    }
  }
  
  $flag = 1 if exists $relic_hash{$orthologous_group_num};
  
}

if ($frame_num != 0){
  $stop_num = $total_num - $frame_num;
  print OUTPUT "$stop_num\n";
}
